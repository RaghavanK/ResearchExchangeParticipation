/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.db;

import Model.bean.Study;
import Model.bean.User;
import Model.data.ConnectionPool;
import Model.data.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Raghavan
 */
public class StudyDB {
    
    public static Study selectUser(String studyCode) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Study study = null; 
        String query = "SELECT * FROM Study "+ "WHERE studyCode = ?";
        try{
            ps = connection.prepareStatement(query);
            ps.setString(1, studyCode);
            rs = ps.executeQuery(); 
            if (rs.next()) {
                study = new Study();
                study.setStudyName(rs.getString("studyName"));
                study.setEmail(rs.getString("Email"));
                study.setStatus(rs.getString("status"));
            }
            return study;
        }catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static ArrayList<Study> getStudies() {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Study study = null; 
        String query = "SELECT * FROM Study "+ "WHERE studyCode = ?";
        try{
            ps = connection.prepareStatement(query);
            
            rs = ps.executeQuery(); 
            ArrayList<Study> studyList = new ArrayList<>();
            if (rs.next()) {
                study = new Study();
                study.setStudyName(rs.getString("studyName"));
                study.setEmail(rs.getString("Email"));
                study.setStatus(rs.getString("status"));
                studyList.add(study);
            }
            return studyList;
        }catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static ArrayList<Study> getStudies(String email) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Study study = null; 
        String query = "SELECT * FROM Study "+ "WHERE studyCode = ?";
        try{
            ps = connection.prepareStatement(query);
            ps.setString(1, email);
            rs = ps.executeQuery(); 
            ArrayList<Study> studyList = new ArrayList<>();
            if (rs.next()) {
                study = new Study();
                study.setStudyName(rs.getString("studyName"));
                study.setEmail(rs.getString("Email"));
                study.setStatus(rs.getString("status"));
                studyList.add(study);
            }
            return studyList;
        }catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static int addStudy(Study study) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query
                = "INSERT INTO Study (Email, FirstName, LastName) "
                + "VALUES (?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, study.getEmail());
            ps.setString(2, study.getStudyName());
            
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static int updateStudy(String sCode, Study study) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Study SET "+ "FirstName = ?,"+ "LastName = ? "
                + "WHERE Email = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, study.getStudyName());

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}
