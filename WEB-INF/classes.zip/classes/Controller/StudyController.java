/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Raghavan
 */
public class StudyController extends HttpServlet{
    
    
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
    
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        String url = "/main.jsp";;
        if("".equals(action)){
            if(null != session.getAttribute("theUser")){
                url = "/main.jsp";
            }else if(null != session.getAttribute("theAdmin")){
                url = "/admin.jsp";    
            }else{
                url= "/main.jsp";
            }
        }else if("participate".equals(action)){
            if(null != session.getAttribute("theUser")){
                if(null != request.getAttribute("StudyCode")){
                    //TODO
                    url = "/question.jsp";
                }else {
                    //TODO
                    url="/participate.jsp";
                }
            }else{
                url = "/login.jsp";
            }
        }else if("edit".equals(action)){
            if(null != session.getAttribute("theUser")){
                url = "/editStudy.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("report".equals(action)){
            if(null != session.getAttribute("theUser")){
                if(null != request.getAttribute("StudyCode")) {
                    //TODO
                    url = "/confirmrep.jsp";
                }else {
                    //TODO
                    url = "/reporth.jsp";
                }
            }else{
                url = "/login.jsp";
            }
        }else if("approve".equals(action)){
            if(null != session.getAttribute("theAdmin")){
                //TODO
                url = "/reportques.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("disapprove".equals(action)){
            if(null != session.getAttribute("theAdmin")){
                url = "/reportques.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("update".equals(action)){
            if(null != session.getAttribute("theUser")){
                //TODO
                url = "/studies.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("add".equals(action)){
            if(null != session.getAttribute("theUser")){
                //TODO
                url = "/studies.jsp";
            }
        }else if("start".equals(action)){
            if(null != session.getAttribute("theUser")){
                //TODO
                url = "/studies.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("stop".equals(action)){
            if(null != session.getAttribute("theUser")){
                //TODO
                url = "/studies.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("answer".equals(action)){
            if(null != session.getAttribute("theUser")){
                //TODO
                url = "/participate.jsp";
            }else{
                url = "/login.jsp";
            }
        }else if("studies".equals(action)){
            if(null != session.getAttribute("theUser")){
                //TODO
                url = "/studies.jsp";
            }else{
                url = "/login.jsp";
            }
        }else{
            if(null != session.getAttribute("theUser")){
                url = "/main.jsp";
            }else if(null != session.getAttribute("theAdmin")){
                url = "/admin.jsp";    
            }else{
                url= "/main.jsp";
            }
        }
         getServletContext().getRequestDispatcher(url).forward(request, response);
    }
    
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    } 
}
