/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.bean.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Raghavan
 */
public class UserController extends HttpServlet{
   
    private User user;
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
     
        String url = "/index.jsp";
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        
        if("".equals(action)){
            url = "home.jsp";
        }else if("login".equals(action)){
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            if(false){//validateCredentails(email,password)
                String userType = user.getType();
                if("participant".equals(userType)){
                    user = new User();
                    session.setAttribute("theUser", user);
                    url = "/main.jsp";
                }else if("Admin".equals(userType)){
                    user = new User();
                    session.setAttribute("theAdmin", user);
                    url = "/admin.jsp";
                }
            }else{
                request.setAttribute("msg", "Please enter a valid email/password");
                url="/login.jsp";
            }
        }else if("create".equals(action)){
            String name=(String)request.getAttribute("name");
            String email = (String)request.getAttribute("email");
            String type = (String)request.getAttribute("type");
            String password = (String)request.getAttribute("password");
            String confirmPassword = (String)request.getAttribute("confirmPassword");
            if(false){//validateCredentials()
                user = new User();
                session.setAttribute("theUser", user);
                url="/main.jsp";
            }else{
                request.setAttribute("msg", "Please enter valid user details");
                url="/signup.jsp";
            }
        }else if("how".equals(action)){
            if(null != session.getAttribute("theUser")){
                url = "/main.jsp";
            }else{
                url="/how.jsp";
            }
        }else if("about".equals(action)){
            if(null != session.getAttribute("theUser")){
                url = "/about.jsp";
            }else{
                url="/aboutl.jsp";
            } 
        }else if("home".equals(action)){
            if(null != session.getAttribute("theUser")){
                url = "/main.jsp";
            }else{
                url="/home.jsp";
            }  
        }else if("main".equals(action)){
             if(null != session.getAttribute("theUser")){
                url = "/main.jsp";
            }else{
                url="/login.jsp";
            } 
        }else if("logout".equals(action)){
            if(null != session.getAttribute("theUser") || null != session.getAttribute("theAdmin")){
                session.invalidate();
            }
            url = "/home.jsp";
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    } 
}
